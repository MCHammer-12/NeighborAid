# NeighborAid

- Setup

1. Install Node (v18+ recommended)
2. Clone the repo
3. Run:
   npm install
4. Set up PostgreSQL using .sql file and create database:
   createdb neighboraid
5. Start server:
   node app/app.js
